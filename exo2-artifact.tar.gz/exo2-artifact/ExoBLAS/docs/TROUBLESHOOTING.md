# Troubleshooting

If there is an error on apple-silicon, try running

```
export SDKROOT=$(xcrun --sdk macosx --show-sdk-path)
```
