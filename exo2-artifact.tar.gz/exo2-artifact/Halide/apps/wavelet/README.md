wavelet is a trivial app designed to show ahead-of-time Generator usage (with
both Make and CMake), as opposed to using direct calls to (e.g.)
Func::compile_to_file().
